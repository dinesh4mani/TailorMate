# Android MotionLayout Carousel
Simple Carousel built with MotionLayout

#### Demo 1
![alt tag](https://raw.githubusercontent.com/faob-dev/MotionLayoutCarousel/master/screenshots/motion_layout.gif)

#### Demo 2
![alt tag](https://raw.githubusercontent.com/faob-dev/MotionLayoutCarousel/master/screenshots/motion_layout2.gif)
